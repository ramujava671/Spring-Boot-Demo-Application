package com.example.demo.model;

import java.util.List;

public class UserResponse {

	private int count;
	private List<User> userList;

	
	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public List<User> getUserList() {
		return userList;
	}

	public void setUserList(List<User> userList) {
		this.userList = userList;
	}

}
